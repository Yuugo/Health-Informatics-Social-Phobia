﻿using System.Windows.Controls;

namespace Moq.Visualizer
{
    public partial class MockVisualizerView : UserControl
    {
        public MockVisualizerView()
        {
            this.InitializeComponent();
        }
    }
}