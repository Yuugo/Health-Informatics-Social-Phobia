XunitLight.Silverlight.dll provides a minimalist port of xUnit APIs on running on top of the Microsoft Silverlight testing framework (see .\..\Microsoft folder)

Thanks Jason Jarrett! http://staxmanade.blogspot.com/