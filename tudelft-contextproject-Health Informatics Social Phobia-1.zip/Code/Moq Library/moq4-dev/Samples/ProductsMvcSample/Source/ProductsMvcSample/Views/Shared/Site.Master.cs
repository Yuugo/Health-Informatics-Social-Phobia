﻿using System.Web.Mvc;

namespace ProductsMvcSample.Views.Shared
{
	public partial class Site : ViewMasterPage
	{
	}
}
