﻿using System.Web.Mvc;

namespace ProductsMvcSample.Views.Home
{
	public partial class Welcome : ViewPage
	{
	}
}
