﻿using System;

namespace Store
{
	public class Product
	{
		public int Id { get; set; }
		public string Name { get; set; }
	}
}
